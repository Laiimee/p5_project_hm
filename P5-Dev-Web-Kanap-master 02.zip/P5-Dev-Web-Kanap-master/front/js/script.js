function getProducts() {
    return fetch('http://localhost:3000/api/products').then(r => r.json());
  }
  
  // https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Global_Objects/Array/map
  // https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Global_Objects/Array/join
  // https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Template_literals
  // https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Functions/Arrow_functions
  function transformProductsToHTML(products) {
    return `
      <ul>
        ${products.map(product => `
          <li>
            <p>id: ${product._id}</p>
            <p>name: ${product.name}</p>
            <p>description: ${product.description}</p>
            <p>price: ${product.price}</p>
            <img width="200" height="120" src="${product.imageUrl}" alt="${product.altTxt}" />
          </li>
        `).join('\n')}
      </ul>
    `
  }
  
  // https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Statements/async_function
  async function init() {
    try {
      const products = await getProducts();
      document.getElementById('items').innerHTML = transformProductsToHTML(products);
    } catch(e) {
      console.error(e)
    }
  }
  
  init()