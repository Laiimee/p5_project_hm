function showProduct() {
    return fetch('http://localhost:3000/api/products').then(r => r.json());
  }
  
  // https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Global_Objects/Array/map
  // https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Global_Objects/Array/join
  // https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Template_literals
  // https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Functions/Arrow_functions
  function transformProductsToHTML(product) {
    return `
        ${product.map(product => `
        <img src="${product.imageUrl}" alt="${product.altTxt}">
        <h1 id="title">${product.name}</h1>
        <p>Prix : <span id="price">${product.price}</span>€</p>
        <p id="description">${product.description}</p>
        <option value="vert">${colors}</option>
        <option value="blanc">${colors}</option> -->
        `).join('\n')}
    `
  }
  
  // https://developer.mozilla.org/fr/docs/Web/JavaScript/Reference/Statements/async_function
  async function init() {
    try {
      const products = await showProduct();
      document.getElementsByClassName('item').innerHTML = transformProductsToHTML(product);
    } catch(e) {
      console.error(e)
    }
  }
  
  init()