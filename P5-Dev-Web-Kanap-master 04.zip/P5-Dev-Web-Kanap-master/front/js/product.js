function getProductById(id){
  return fetch (`http://localhost:3000/api/products/${id}`).then(r => r.json());

}

function transformProductToHTML(product) {
  let itemImg = document.querySelector('.item__img');
  itemImg.innerHTML = `<img src=${product.imageUrl} alt=${product.altTxt}>`;

  let itemTitle = document.querySelector('#title');
  itemTitle.innerHTML = `${product.name}`;

  let itemPrice = document.querySelector('#price');
  itemPrice.innerHTML = `${product.price}`;

  let itemDescription = document.querySelector('#description');
  itemDescription.innerHTML = `${product.description}`;

  let itemColors = document.querySelector('#colors');
  for (const color of product.colors) {
    let option = document.createElement('option');
    option.value = color;
    option.innerHTML = color;
    itemColors.append(option);
  }
}

function getId(){
  let url =  new URL(window.location.href);
  console.log(window.location.href);

  let search_params = new URLSearchParams(url.search); 
  if(search_params.has('id')) {
    let id = search_params.get('id');
    console.log(id);

    return id;
  }  
}
console.log(getId());

async function init() {
  try {
    const product = await getProductById(getId());
    transformProductToHTML(product);
  } catch(e) {
    console.error(e)
  }
}
init()

/* 
to do page pannier 

creer un tableau vide 

=> local.storage <=

recup
id
color
Number

afficher dans panier 

option regarder deja une ligne / ajouter m^me value ajouter quantité
=> if{} else{} <=

FULL console.log();
*/