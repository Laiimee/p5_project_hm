

// Call back endfonction données a then //
/* async function ShowProducts (){
    const resultat = await ('http://localhost:3000/api/products.then(r => r.json)');
}
 */



let ShowProducts = document.getElementsByClassName('productName') + document.getElementsByClassName('productDescription');

/* fetch('http://localhost:3000/api/products')
.then(function(res) {
  if (res.ok) {
    return res.json();
  }
})
.then(function(value) {
  console.log(value);
})
.catch(function(err) {
  // Une erreur est survenue
}); */

document
.getElementById("items")
.innerHTML='ShowProduct';
console.log(ShowProducts);


console.log(ShowProducts.nextElementSibling);
console.log("#item", document.getElementById("item"));

/* const = ; */
/* function init (){
}
function transformToHtml(){
} 
 */
function result() {
    fetch("http://localhost:3000/api/products")
    .then(function(res) {
    // Récupérer la requete
      if (res.ok) {
        return res.json();
      }
    })
    // Parcourir la requete
    .then(function(value) {
        document
            .getElementById("items")
            .innerText = value.queryString.products;
        console.log('#item', document.getElementById('item'));
      })
    .catch(function(err) {
      // Une erreur est survenue
    });
  }

/* fetch('http://localhost:3000/api/products').then(
    function(Result){
        // Récupérer la requete
        function  (){
            if(res.ok){
                return res.json();
            }
        }

        function (){
        }   
    }
) */

/* document.getElementById('product').innerHtml=; */

/* <
innerHtml => manipuler le HTML bourine
changer le json 
document.getElementById(product)=

function de transformation 1 information par function
1 function prendre objet json transform en Text
funtion init qui manipule la function  */